import Foundation

struct LinkedListValue {
    var key: Int
    var value: Int
}

class LinkedListNode<T> {
    var value: T
    var next: LinkedListNode?
    weak var previous: LinkedListNode?

    public init(value: T) {
        self.value = value
    }
}

class LinkedList<T> {
    private var head: LinkedListNode<T>?

    var isEmpty: Bool {
        return head == nil
    }

    var first: LinkedListNode<T>? {
        return head
    }
    
    var last: LinkedListNode<T>? {
        guard var node = head else { return nil }
  
        while let next = node.next {
            node = next
        }
        return node
    }
}

class HashTableNode<T> {
    var value: T
    var key: Int
    var nextNode: HashTableNode?
    init(value: T, key: Int) {
        self.value = value
        self.key = key
    }
}

class SymbolTable<T> {
    private var bucket: [HashTableNode<T>?]
    
    init(bucketSize: Int) {
        bucket = Array(repeating: nil, count: bucketSize)
    }
    
    func addElement(_ element: T) {
        let hashKey = bucket.compactMap { $0 }.count
        let node = HashTableNode(value: element, key: hashKey)
        let index = findIndex(forKey: hashKey)
        var auxNode = bucket[index]
        if auxNode == nil {
           bucket[index] = node
            return
        }
        while auxNode?.nextNode != nil {
            if auxNode?.key == hashKey || auxNode?.nextNode?.key == hashKey {
                auxNode = [auxNode, auxNode?.nextNode].first(where: {$0?.key == hashKey})!
                auxNode?.value = element
            }
            auxNode = auxNode?.nextNode
        }
        auxNode?.nextNode = node
    }
    
    func getElement(forKey hashKey: Int) -> T? {
        let index = findIndex(forKey: hashKey)
        var node = bucket[index]
        while node != nil {
            if node?.key == hashKey { return node?.value } else {
                node = node?.nextNode
            }
        }
        return nil
    }
    
    private func findIndex(forKey hashKey: Int) -> Int {
        return (hashKey >= 0 ? hashKey % bucket.capacity : -1)
    }
}

class Scanner {
    private let ReservedWords = ["if", "elif", "else", "class", "struct", "nil", "let", "var", "int", "init", "deinit", "char", "string", "array", "for", "forEach", "do", "try", "catch", "readLine", "print", "while"]
    private let Separators = ["[", "]", "{", "}", "(", ")", ":", "->", "."]
    private let Operators = ["+", "-", "*", "/", "=", "==", "<", ">", "<", "=", ">", "=", "|", "|", "&", "&", "%", "!", "!=", "++"]
    
    private let symbolTable = SymbolTable<String>(bucketSize: 131)
    private let programInternalForm = LinkedList<LinkedListValue>()
    
    private func tokenize(content: String) -> [String] {
        let separators = Separators.reduce("") { $0 + $1 }
        let tokenizedContent = content.split(separator: "[{};: ,\\[\\]()\"]").map { possibleToken in
            return possibleToken.count > 0 ? String(possibleToken) : ""
        }
        return tokenizedContent
    }
    
    private func configureSymbolTable() {
        let tokens = tokenize(content: "Example")
        if tokens.count == 0 { return }
        tokens.forEach { token in
            print(token)
            if ReservedWords.contains(token) || Operators.contains(token) {
                print("Token not available")
            } else {
                symbolTable.addElement(token)
            }
        }
    }
    private func scan() {
        configureSymbolTable()
        print(symbolTable)
    }
}
